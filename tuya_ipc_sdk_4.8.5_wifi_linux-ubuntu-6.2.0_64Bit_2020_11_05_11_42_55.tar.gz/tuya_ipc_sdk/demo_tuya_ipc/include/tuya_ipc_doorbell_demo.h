#ifndef __TUYA_DOORBELL_DEMO_H_
#define __TUYA_DOORBELL_DEMO_H_
#include <stdio.h>

void doorbell_handler();

OPERATE_RET TUYA_APP_Enable_DOORBELL(VOID);


#endif
